package tg.ipnet.university.tp3;

public class Program3 {

}
